package com.ssfreshmart.app;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.text.InputType;

import org.json.JSONObject;

import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

public class MainActivity extends Activity implements PaymentResultListener {
    String[] names={"Apple 🍎","Banana 🍌","Orange 🍊","Grapes 🍇","Mango 🥭","Pomegranate ❤️","Papaya 🧡","Watermelon 🍉"};
    int[] prices={180,70,120,140,160,220,80,90};
    int cart=0;
    int cartTotal=0;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        LinearLayout box=findViewById(R.id.products);
        for(int i=0;i<names.length;i++){
            final int p=prices[i];
            LinearLayout row=new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(8,16,8,8);

            TextView t=new TextView(this);
            t.setText(names[i]+"\n₹"+p+" / unit");
            t.setTextSize(17);
            t.setTextColor(Color.rgb(23,51,35));
            t.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));

            Button add=new Button(this);
            add.setText("Add +");
            add.setOnClickListener(v->{
                cart++;
                cartTotal += p;
                Toast.makeText(this,"Added • "+cart+" item(s)",Toast.LENGTH_SHORT).show();
            });
            row.addView(t); row.addView(add); box.addView(row);
        }

        findViewById(R.id.cartButton).setOnClickListener(v->showCheckout());
    }

    private EditText input(String hint, int type){
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setInputType(type);
        e.setPadding(18,12,18,12);
        return e;
    }

    private void showCheckout(){
        if(cart==0){
            new AlertDialog.Builder(this).setTitle("Your cart is empty")
                    .setMessage("Add some fresh fruits first.")
                    .setPositiveButton("OK",null).show();
            return;
        }

        LinearLayout form=new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        int pad=20;
        form.setPadding(pad,8,pad,0);

        TextView total=new TextView(this);
        total.setText("Order total: ₹"+cartTotal);
        total.setTextSize(20);
        total.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        total.setTextColor(Color.rgb(8,122,61));
        form.addView(total);

        EditText name=input("Full name",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText mobile=input("Mobile number",InputType.TYPE_CLASS_PHONE);
        EditText address=input("Complete delivery address",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        address.setMinLines(3);
        form.addView(name); form.addView(mobile); form.addView(address);

        RadioGroup payment=new RadioGroup(this);
        RadioButton online=new RadioButton(this); online.setText("Pay online (UPI / Card / Netbanking)"); online.setChecked(true);
        RadioButton cod=new RadioButton(this); cod.setText("Cash on delivery");
        payment.addView(online); payment.addView(cod); form.addView(payment);

        ScrollView scroll=new ScrollView(this); scroll.addView(form);
        AlertDialog dialog=new AlertDialog.Builder(this)
                .setTitle("SS FreshMart Checkout")
                .setView(scroll)
                .setNegativeButton("Cancel",null)
                .setPositiveButton("Continue",null)
                .create();

        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if(name.getText().toString().trim().isEmpty() || mobile.getText().toString().trim().length()<10 || address.getText().toString().trim().isEmpty()){
                Toast.makeText(this,"Please enter name, valid mobile and address",Toast.LENGTH_LONG).show();
                return;
            }
            if(cod.isChecked()){
                placeCodOrder(name.getText().toString(), mobile.getText().toString(), address.getText().toString());
                dialog.dismiss();
            } else {
                dialog.dismiss();
                startRazorpay(name.getText().toString(), mobile.getText().toString(), address.getText().toString());
            }
        }));
        dialog.show();
    }

    private void placeCodOrder(String name,String mobile,String address){
        new AlertDialog.Builder(this)
                .setTitle("Order received ✅")
                .setMessage("Thank you, "+name+"!\n\nTotal: ₹"+cartTotal+"\nPayment: Cash on delivery\n\nYour order is recorded on this device. A real online order database/admin panel must be connected before launch.")
                .setPositiveButton("OK",(d,w)->{cart=0;cartTotal=0;})
                .show();
    }

    private void startRazorpay(String name,String mobile,String address){
        if(PaymentConfig.RAZORPAY_KEY_ID.contains("REPLACE_ME")){
            new AlertDialog.Builder(this)
                    .setTitle("Online payment setup needed")
                    .setMessage("The checkout screen is ready, but your Razorpay merchant Key ID has not been added yet. Create/activate your merchant account, then replace the test Key ID in PaymentConfig.java. Never add the Key Secret to the app.")
                    .setPositiveButton("OK",null).show();
            return;
        }

        Checkout checkout = new Checkout();
        checkout.setKeyID(PaymentConfig.RAZORPAY_KEY_ID);
        try {
            JSONObject options = new JSONObject();
            options.put("name", "SS FreshMart");
            options.put("description", "Fresh fruit order");
            options.put("currency", "INR");
            options.put("amount", cartTotal * 100);
            options.put("prefill.name", name);
            options.put("prefill.contact", mobile);
            checkout.open(this, options);
        } catch (Exception e) {
            Toast.makeText(this,"Unable to open payment: "+e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onPaymentSuccess(String paymentId){
        new AlertDialog.Builder(this)
                .setTitle("Payment successful ✅")
                .setMessage("Payment ID: "+paymentId+"\n\nFor production, the payment must be verified on a secure backend before the order is marked paid.")
                .setPositiveButton("OK",(d,w)->{cart=0;cartTotal=0;})
                .show();
    }

    @Override public void onPaymentError(int code,String response){
        new AlertDialog.Builder(this)
                .setTitle("Payment not completed")
                .setMessage(response==null?"Please try again.":response)
                .setPositiveButton("OK",null).show();
    }
}
