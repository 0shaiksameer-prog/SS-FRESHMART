package com.ssfreshmart.app;

/**
 * Payment configuration.
 * Replace ONLY the public Razorpay Key ID after creating a Razorpay merchant account.
 * NEVER put the Razorpay Key Secret inside the Android app or GitHub repository.
 */
public final class PaymentConfig {
    private PaymentConfig() {}

    public static final String RAZORPAY_KEY_ID = "rzp_test_REPLACE_ME";
}
