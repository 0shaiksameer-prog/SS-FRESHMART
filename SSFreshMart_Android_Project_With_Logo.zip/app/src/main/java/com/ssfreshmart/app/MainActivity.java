package com.ssfreshmart.app;

import android.app.*; import android.os.*; import android.graphics.Color; import android.content.*; import android.view.*; import android.widget.*;

public class MainActivity extends Activity {
 String[] names={"Apple 🍎","Banana 🍌","Orange 🍊","Grapes 🍇","Mango 🥭","Pomegranate ❤️","Papaya 🧡","Watermelon 🍉"};
 int[] prices={180,70,120,140,160,220,80,90}; int cart=0;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  LinearLayout box=findViewById(R.id.products);
  for(int i=0;i<names.length;i++){ final int p=prices[i];
   LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(8,16,8,8);
   TextView t=new TextView(this); t.setText(names[i]+"\n₹"+p+" / unit"); t.setTextSize(17); t.setTextColor(Color.rgb(23,51,35)); t.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));
   Button add=new Button(this); add.setText("Add +"); add.setOnClickListener(v->{cart++; Toast.makeText(this,"Added to cart • "+cart+" item(s)",Toast.LENGTH_SHORT).show();});
   row.addView(t); row.addView(add); box.addView(row);
  }
  findViewById(R.id.cartButton).setOnClickListener(v->new AlertDialog.Builder(this).setTitle("SS FreshMart Cart").setMessage("Your cart has "+cart+" item(s).\n\nCheckout and live online payment can be connected in the production version.").setPositiveButton("OK",null).show());
 }
}
